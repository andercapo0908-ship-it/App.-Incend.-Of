
import 'package:flutter/material.dart';

void main() {
  runApp(const IncendeiaApp());
}

class IncendeiaApp extends StatelessWidget {
  const IncendeiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Incendeia ON AM',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212),
        primaryColor: Colors.red,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    GalleryScreen(),
    MastersScreen(),
    GraduationScreen(),
    ChatScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("INCENDEIA ON AM"),
        centerTitle: true,
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.red,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.black,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.photo), label: "Galeria"),
          BottomNavigationBarItem(icon: Icon(Icons.sports_martial_arts), label: "Mestres"),
          BottomNavigationBarItem(icon: Icon(Icons.workspace_premium), label: "Graduação"),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: "Chat"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Perfil"),
        ],
      ),
    );
  }
}

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Galeria - Curtir / Comentar / Upload"));
  }
}

class MastersScreen extends StatelessWidget {
  const MastersScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Mestres - Cadastro e Biografia"));
  }
}

class GraduationScreen extends StatelessWidget {
  const GraduationScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Graduação - Sistema de Cordas"));
  }
}

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Chat - Tempo Real"));
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Meu Perfil - Editável"));
  }
}
